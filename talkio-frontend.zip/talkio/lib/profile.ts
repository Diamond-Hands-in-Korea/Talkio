import { founder, me } from "@/lib/seed";

export type UserProfile = {
  linkedIn: string;
  cv: string;
  portfolio: string;
  github: string;
  companyWebsite: string;
  conferenceGoal: string;
};

export const PROFILE_STORAGE_KEY = "talkio-user-profile";

export const defaultUserProfile: UserProfile = {
  linkedIn: founder.linkedIn,
  cv: "",
  portfolio: "",
  github: "",
  companyWebsite: "",
  conferenceGoal: me.goals,
};

export function loadUserProfile(): UserProfile {
  if (typeof window === "undefined") return defaultUserProfile;

  try {
    const raw = window.localStorage.getItem(PROFILE_STORAGE_KEY);
    if (!raw) return defaultUserProfile;
    return { ...defaultUserProfile, ...JSON.parse(raw) };
  } catch {
    return defaultUserProfile;
  }
}

export function saveUserProfile(profile: UserProfile) {
  window.localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
}

export type ProfileLink = {
  label: string;
  href: string;
};

export function getProfileLinks(profile: UserProfile): ProfileLink[] {
  const links: ProfileLink[] = [];

  if (profile.linkedIn.trim()) {
    links.push({ label: "LinkedIn", href: profile.linkedIn.trim() });
  }
  if (profile.cv.trim()) {
    links.push({ label: "CV", href: profile.cv.trim() });
  }
  if (profile.portfolio.trim()) {
    links.push({ label: "Portfolio", href: profile.portfolio.trim() });
  }
  if (profile.github.trim()) {
    links.push({ label: "GitHub", href: profile.github.trim() });
  }
  if (profile.companyWebsite.trim()) {
    links.push({ label: "Company website", href: profile.companyWebsite.trim() });
  }

  return links;
}
