export const startup = {
  tagline: "The connection shouldn't end when the conversation does.",
  description:
    "Talkio lets you be fully present, then turns the people you met into the partnerships, intros, and doors that actually open — long after you've left the room.",
  steps: [
    {
      title: "Scan & connect",
      body: "Swap QR codes at the event. No awkward contact-card shuffle — just a tap and you're linked.",
    },
    {
      title: "Capture the conversation",
      body: "Talkio listens in the background while you stay in the moment. Transcripts and highlights appear automatically.",
    },
    {
      title: "Follow up with intent",
      body: "Days later, get ranked recommendations and drafted messages grounded in what you actually talked about.",
    },
  ],
  pitch:
    "Conference networking breaks down after the handshake. Notes get lost, context fades, and the people who could change your trajectory slip through. Talkio is the layer between being present in the room and showing up with the right follow-up at the right time.",
};

export const founder = {
  name: "Marcus Chen",
  role: "Co-founder & engineer",
  headline: "Software engineer · building AgentDesk",
  location: "San Francisco",
  bio: "Marcus spent five years as a backend engineer at a payments company before co-founding AgentDesk — workflow tooling for teams shipping AI agents into production. He's at KBW to find integration partners and early design partners for agent payment hooks.",
  linkedIn: "https://www.linkedin.com/in/marcus-chen-dev",
};

export const me = {
  name: founder.name,
  headline: "Co-founder @ AgentDesk · agent workflow tooling",
  location: "Seoul (KBW)",
  goals:
    "Developers building agent-to-agent payment infrastructure (x402), and design partners for our treasury-automation integrations.",
};

export const contact = {
  name: "Jiwon Park",
  headline: "Co-founder @ Relay · stablecoin payment rails",
  location: "Seoul",
  goals:
    "Early integration partners and developers building on agentic payment standards.",
};

export const transcript = `Marcus: Hey — Marcus from AgentDesk. Are you here for the agentic payments panel tomorrow?

Jiwon: Jiwon, Relay. Yeah, that's exactly why I'm at KBW. We're building stablecoin payment rails for agents.

Marcus: Perfect timing. We've been prototyping x402 hooks in AgentDesk for agent-to-agent treasury moves — still early, but the integration gap is real.

Jiwon: Same problem on our side. Relay ships an x402-compatible settlement layer next month. We're looking for developers building agent-to-agent payment flows to stress-test it before launch.

Marcus: That's literally the use case we're piloting next week. What's the integration surface look like?

Jiwon: REST + webhook callbacks today, SDK in Q4. For pilot partners we'd co-design the agent handshake — quote, pay, settle — all in stablecoin.

Marcus: We're also scoping treasury-automation workflows for ops teams. If Relay can settle agent intents, that's a design partner conversation too.

Jiwon: Open to a pilot partner before the public launch. If AgentDesk can bring real agent traffic, we can prioritize your use case in the first release.

Marcus: Let's compare notes after the panel. I'll bring our integration spec.

Jiwon: Deal. I'll send the sandbox credentials — ping me on Telegram.`;

export const highlights = [
  "Relay ships an x402-compatible settlement layer next month",
  "Looking for developers building agent-to-agent payment flows",
  "Open to a pilot partner before the public launch",
];

export const summary = `At Korean Blockchain Week, Marcus and Jiwon mapped a clear overlap: AgentDesk's x402 workflow hooks and Relay's upcoming settlement layer target the same agent-to-agent payment gap. Jiwon is actively recruiting pilot partners before next month's launch, and Marcus's treasury-automation integrations could supply real traffic and co-design feedback. A follow-up with sandbox access and a spec comparison is the natural next step.`;

export const recommendation = {
  name: contact.name,
  matchPercent: 94,
  reason:
    "Strong x402 overlap — Relay's settlement layer launches next month and Jiwon explicitly asked for pilot partners building agent-to-agent payment flows, which matches Marcus's AgentDesk integrations.",
  draftedMessage: `Hi Jiwon — great meeting you at KBW yesterday. Your x402-compatible settlement layer timeline lines up closely with what we're building at AgentDesk. Would you have 30 minutes next week to walk through our integration spec and explore a pilot? Happy to bring real test traffic if the sandbox is ready.`,
};

export const qrValue = "talkio://contact/jiwon-park";

export type RecordingStatus = "recording" | "processing" | "complete";

export type Recording = {
  id: string;
  contactName: string;
  contactHeadline: string;
  event: string;
  date: string;
  duration: string;
  status: RecordingStatus;
  summary: string;
  highlights: string[];
  transcript: string;
};

export const recordings: Recording[] = [
  {
    id: "jiwon-kbw",
    contactName: contact.name,
    contactHeadline: contact.headline,
    event: "Korean Blockchain Week",
    date: "Jun 24, 2025",
    duration: "04:32",
    status: "complete",
    summary,
    highlights,
    transcript,
  },
  {
    id: "elena-kbw",
    contactName: "Elena Vasquez",
    contactHeadline: "Co-founder @ ChainOps · DAO treasury automation",
    event: "Korean Blockchain Week",
    date: "Jun 24, 2025",
    duration: "02:18",
    status: "complete",
    summary:
      "Elena is building treasury automation for DAOs and asked about agent-triggered payment hooks. Marcus shared AgentDesk's workflow layer; Elena offered a sandbox walkthrough for multi-sig treasury flows.",
    highlights: [
      "ChainOps automates DAO treasury ops with agent triggers",
      "Interested in AgentDesk workflow hooks for payment intents",
      "Offered a sandbox walkthrough next week",
    ],
    transcript:
      "Marcus: Elena — Marcus, AgentDesk. Saw your panel on DAO ops.\n\nElena: Same stack we're chasing — agents that actually move treasury without a human in the loop.",
  },
  {
    id: "tom-kbw",
    contactName: "Tom Okonkwo",
    contactHeadline: "DevRel @ OpenAgents · agent interoperability",
    event: "Korean Blockchain Week",
    date: "Jun 23, 2025",
    duration: "01:05",
    status: "processing",
    summary: "Processing conversation summary…",
    highlights: [],
    transcript: "Marcus: Tom — quick intro before the keynote…",
  },
];

export type ProfileMatch = {
  id: string;
  name: string;
  headline: string;
  location: string;
  theirGoals: string;
  matchPercent: number;
  reason: string;
  overlapTags: string[];
  recordingId?: string;
};

export const profileMatches: ProfileMatch[] = [
  {
    id: "jiwon-park",
    name: contact.name,
    headline: contact.headline,
    location: contact.location,
    theirGoals: contact.goals,
    matchPercent: 94,
    reason:
      "Your conference goal targets x402 infrastructure and treasury-automation partners. Jiwon is recruiting pilot partners for Relay's x402 settlement layer — direct overlap on agent-to-agent payment flows.",
    overlapTags: ["x402", "pilot partner", "agent payments", "treasury automation"],
    recordingId: "jiwon-kbw",
  },
  {
    id: "elena-vasquez",
    name: "Elena Vasquez",
    headline: "Co-founder @ ChainOps · DAO treasury automation",
    location: "Seoul",
    theirGoals:
      "Teams building agent-triggered treasury workflows and design partners for DAO ops tooling.",
    matchPercent: 81,
    reason:
      "You listed treasury-automation integrations as a goal. Elena builds DAO treasury automation and wants agent payment hooks — strong fit for a co-design conversation.",
    overlapTags: ["treasury automation", "agent workflows", "DAO ops"],
    recordingId: "elena-kbw",
  },
  {
    id: "tom-okonkwo",
    name: "Tom Okonkwo",
    headline: "DevRel @ OpenAgents · agent interoperability",
    location: "Singapore",
    theirGoals:
      "Developers standardizing agent handshakes and cross-platform agent identity.",
    matchPercent: 62,
    reason:
      "Partial overlap on agent infrastructure. Tom focuses on interoperability standards rather than payment settlement — worth a second conversation, lower priority than payment-rail partners.",
    overlapTags: ["agent standards", "interoperability"],
    recordingId: "tom-kbw",
  },
  {
    id: "sara-lim",
    name: "Sara Lim",
    headline: "Investor @ Horizon Ventures · infra & devtools",
    location: "Seoul",
    theirGoals: "Pre-seed teams building developer infrastructure in APAC.",
    matchPercent: 48,
    reason:
      "Sara invests broadly in devtools. AgentDesk's angle is relevant but her mandate is funding, not integration partnerships — limited match against your stated conference goals.",
    overlapTags: ["devtools", "APAC"],
  },
];

export function getRecordingById(id: string): Recording | undefined {
  return recordings.find((recording) => recording.id === id);
}
