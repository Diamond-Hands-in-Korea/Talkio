import { Panel } from "./Panel";

type Contact = {
  name: string;
  headline: string;
  location: string;
};

type ContactCardProps = {
  contact: Contact;
  compact?: boolean;
};

export function ContactCard({ contact, compact = false }: ContactCardProps) {
  return (
    <Panel className={`animate-fade-in ${compact ? "py-5" : ""}`}>
      <p className={compact ? "button-cap text-on-primary" : "display-lg text-[1.25rem] leading-tight tracking-[0.06em]"}>
        {contact.name}
      </p>
      <p className="body-lg mt-2">{contact.headline}</p>
      {!compact && <p className="micro-cap mt-4">{contact.location}</p>}
    </Panel>
  );
}
