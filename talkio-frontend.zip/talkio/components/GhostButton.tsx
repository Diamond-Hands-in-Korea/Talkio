import Link from "next/link";
import type { ReactNode } from "react";

type GhostButtonProps = {
  href: string;
  children: ReactNode;
  className?: string;
  variant?: "dark" | "light";
};

export function GhostButton({
  href,
  children,
  className = "",
  variant = "dark",
}: GhostButtonProps) {
  const styles =
    variant === "dark"
      ? "border-on-primary text-on-primary bg-transparent hover:bg-white/5"
      : "border-ink text-ink bg-transparent hover:bg-black/5";

  return (
    <Link
      href={href}
      className={`button-cap inline-flex items-center justify-center rounded-[32px] border px-6 py-[18px] transition-colors ${styles} ${className}`}
    >
      {children}
    </Link>
  );
}
