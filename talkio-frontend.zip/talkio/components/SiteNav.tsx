"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { TalkioLogo } from "./TalkioLogo";

const links = [
  { href: "/demo", label: "Demo" },
  { href: "/recordings", label: "Recordings" },
  { href: "/matches", label: "Matches" },
  { href: "/profile", label: "Profile" },
];

export function SiteNav() {
  const pathname = usePathname();

  return (
    <header className="site-nav">
      <Link href="/" className="site-nav-brand">
        <TalkioLogo size={32} />
        <span>TALKIO</span>
      </Link>
      <nav className="site-nav-links" aria-label="Main">
        {links.map((link) => {
          const active =
            pathname === link.href || pathname.startsWith(`${link.href}/`);

          return (
            <Link
              key={link.href}
              href={link.href}
              className={active ? "site-nav-active" : undefined}
              aria-current={active ? "page" : undefined}
            >
              {link.label}
            </Link>
          );
        })}
      </nav>
    </header>
  );
}
