import Link from "next/link";
import type { ReactNode } from "react";

type PrimaryButtonProps = {
  href: string;
  children: ReactNode;
  className?: string;
  fullWidth?: boolean;
};

export function PrimaryButton({
  href,
  children,
  className = "",
  fullWidth = true,
}: PrimaryButtonProps) {
  return (
    <Link
      href={href}
      className={`inline-flex h-11 items-center justify-center rounded-full bg-primary px-6 text-[15px] font-semibold text-on-primary shadow-[0_4px_16px_rgba(200,85,61,0.28)] transition-colors hover:bg-primary-active ${
        fullWidth ? "w-full" : ""
      } ${className}`}
    >
      {children}
    </Link>
  );
}
