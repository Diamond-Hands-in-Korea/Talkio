type TalkioLogoProps = {
  className?: string;
  size?: number;
};

export function TalkioLogo({ className = "", size = 48 }: TalkioLogoProps) {
  const height = Math.round(size * 0.58);

  return (
    <svg
      width={size}
      height={height}
      viewBox="0 0 48 28"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden
    >
      <circle cx="9" cy="14" r="6" fill="#FFFFFF" />
      <circle cx="39" cy="14" r="6" fill="#FFFFFF" fillOpacity="0.55" />
      <path
        d="M15 14C15 14 21 4 24 4C27 4 33 14 33 14"
        stroke="#FFFFFF"
        strokeWidth="2.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
