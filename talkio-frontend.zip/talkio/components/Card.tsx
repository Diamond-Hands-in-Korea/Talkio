import type { ReactNode } from "react";

type CardTint = "none" | "mint" | "lavender" | "peach" | "sky" | "rose" | "warm";

type CardProps = {
  children: ReactNode;
  className?: string;
  tint?: CardTint;
  featured?: boolean;
};

const tintStyles: Record<Exclude<CardTint, "none">, string> = {
  mint: "border-[#c5e8dc] bg-surface-mint",
  lavender: "border-[#d8cce8] bg-surface-lavender",
  peach: "border-[#f0d4c0] bg-surface-peach",
  sky: "border-[#c5d8ef] bg-surface-sky",
  rose: "border-[#e8ccd4] bg-surface-rose",
  warm: "border-[#f0d0c4] bg-surface-warm",
};

export function Card({
  children,
  className = "",
  tint = "none",
  featured = false,
}: CardProps) {
  if (featured) {
    return (
      <div
        className={`rounded-2xl border-2 border-accent-mint bg-surface-card p-6 shadow-[0_8px_32px_rgba(61,155,128,0.12)] ${className}`}
      >
        {children}
      </div>
    );
  }

  const tintClass = tint !== "none" ? tintStyles[tint] : "border-hairline bg-surface-card";

  return (
    <div className={`rounded-2xl border p-6 text-ink ${tintClass} ${className}`}>
      {children}
    </div>
  );
}
