import type { ReactNode } from "react";

type PageShellProps = {
  children: ReactNode;
  className?: string;
  wide?: boolean;
};

export function PageShell({ children, className = "", wide = false }: PageShellProps) {
  return (
    <div className={`${wide ? "page-inner-wide" : "page-inner"} ${className}`}>
      {children}
    </div>
  );
}
