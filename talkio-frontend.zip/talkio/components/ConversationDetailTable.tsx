type ConversationDetailTableProps = {
  recordingLabel: string;
  recordingValue: React.ReactNode;
  contactName: string;
  contactHeadline: string;
  transcript: React.ReactNode;
  summary?: React.ReactNode;
  highlights?: string[];
  summaryPending?: boolean;
  highlightsPending?: boolean;
};

export function ConversationDetailTable({
  recordingLabel,
  recordingValue,
  contactName,
  contactHeadline,
  transcript,
  summary,
  highlights,
  summaryPending = false,
  highlightsPending = false,
}: ConversationDetailTableProps) {
  return (
    <div className="data-table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th scope="col">Field</th>
            <th scope="col">Detail</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="data-table-label">Recording</td>
            <td>
              <div className="flex items-center gap-3">
                {recordingValue}
                <span className="micro-cap text-on-primary">{recordingLabel}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td className="data-table-label">Contact</td>
            <td>
              <p className="button-cap text-on-primary">{contactName}</p>
              <p className="body-lg mt-1">{contactHeadline}</p>
            </td>
          </tr>
          <tr>
            <td className="data-table-label">Transcript</td>
            <td className="data-table-prose">{transcript}</td>
          </tr>
          <tr>
            <td className="data-table-label">Summary</td>
            <td className="data-table-prose">
              {summaryPending ? (
                <span className="micro-cap text-on-primary-mute">Pending — end conversation to generate</span>
              ) : (
                summary
              )}
            </td>
          </tr>
          <tr>
            <td className="data-table-label">Highlights</td>
            <td>
              {highlightsPending ? (
                <span className="micro-cap text-on-primary-mute">Detecting after transcript completes</span>
              ) : highlights && highlights.length > 0 ? (
                <ul className="data-table-list">
                  {highlights.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              ) : (
                <span className="micro-cap text-on-primary-mute">None yet</span>
              )}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
