import { Panel } from "./Panel";

type Profile = {
  name: string;
  headline: string;
  location: string;
  goals: string;
};

type ProfileCardProps = {
  profile: Profile;
  showGoals?: boolean;
};

export function ProfileCard({ profile, showGoals = true }: ProfileCardProps) {
  return (
    <Panel className="animate-fade-in">
      <p className="display-lg text-[1.25rem] leading-tight tracking-[0.06em]">
        {profile.name}
      </p>
      <p className="body-lg mt-2 text-on-primary-mute">{profile.headline}</p>
      <p className="micro-cap mt-4">{profile.location}</p>
      {showGoals && (
        <div className="mt-6 border-t border-hairline-dark pt-6">
          <p className="micro-cap">Looking for</p>
          <p className="body-lg mt-3">{profile.goals}</p>
        </div>
      )}
    </Panel>
  );
}
