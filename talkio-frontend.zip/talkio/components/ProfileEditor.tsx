"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Panel } from "@/components/Panel";
import { ProfileField } from "@/components/ProfileField";
import { SiteNav } from "@/components/SiteNav";
import {
  defaultUserProfile,
  getProfileLinks,
  loadUserProfile,
  saveUserProfile,
  type UserProfile,
} from "@/lib/profile";
import { founder } from "@/lib/seed";

export function ProfileEditor() {
  const [profile, setProfile] = useState<UserProfile>(defaultUserProfile);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setProfile(loadUserProfile());
  }, []);

  function updateField<K extends keyof UserProfile>(key: K, value: UserProfile[K]) {
    setSaved(false);
    setProfile((current) => ({ ...current, [key]: value }));
  }

  function handleSave(event: React.FormEvent) {
    event.preventDefault();
    saveUserProfile(profile);
    setSaved(true);
  }

  const links = getProfileLinks(profile);

  return (
    <>
      <SiteNav />
      <div className="page-inner animate-fade-in">
        <p className="micro-cap">Your profile</p>
        <h1 className="display-lg mt-4">Before the conference</h1>
        <p className="body-lg mt-6 max-w-[52ch]">
          Add your links and what you&apos;re looking for at this event. Talkio uses
          this context when matching follow-ups.
        </p>

        <Panel className="mt-10">
          <p className="micro-cap">{founder.role}</p>
          <p className="button-cap mt-4 text-on-primary">{founder.name}</p>
          <p className="body-lg mt-2">{founder.headline}</p>
          <p className="micro-cap mt-4">{founder.location}</p>
          <p className="body-lg mt-6 border-t border-hairline-dark pt-6">{founder.bio}</p>
        </Panel>

        <form onSubmit={handleSave} className="mt-6 space-y-6">
          <Panel>
            <p className="micro-cap">Links & materials</p>
            <p className="body-lg mt-3">
              Add the URLs you want Talkio to know about before you hit the conference
              floor.
            </p>
            <div className="mt-6 space-y-5">
              <ProfileField
                id="linkedIn"
                label="LinkedIn"
                value={profile.linkedIn}
                onChange={(value) => updateField("linkedIn", value)}
                placeholder="https://linkedin.com/in/you"
              />
              <ProfileField
                id="cv"
                label="CV"
                value={profile.cv}
                onChange={(value) => updateField("cv", value)}
                placeholder="Link to your resume or CV"
              />
              <ProfileField
                id="portfolio"
                label="Portfolio"
                value={profile.portfolio}
                onChange={(value) => updateField("portfolio", value)}
                placeholder="https://yourportfolio.com"
              />
              <ProfileField
                id="github"
                label="GitHub"
                value={profile.github}
                onChange={(value) => updateField("github", value)}
                placeholder="https://github.com/you"
              />
              <ProfileField
                id="companyWebsite"
                label="Company website"
                value={profile.companyWebsite}
                onChange={(value) => updateField("companyWebsite", value)}
                placeholder="https://yourcompany.com"
              />
            </div>
          </Panel>

          <Panel>
            <label htmlFor="conferenceGoal" className="block">
              <span className="micro-cap">Conference goal</span>
              <p className="body-lg mt-3">
                Who are you trying to meet at this event, and what outcome would make
                it a win?
              </p>
              <textarea
                id="conferenceGoal"
                value={profile.conferenceGoal}
                onChange={(event) => updateField("conferenceGoal", event.target.value)}
                rows={4}
                placeholder="e.g. Design partners for agent-to-agent payment infrastructure..."
                className="textarea-dark mt-4"
              />
            </label>
          </Panel>

          <button
            type="submit"
            className="button-cap inline-flex items-center justify-center rounded-[32px] border border-on-primary px-6 py-[18px] text-on-primary transition-colors hover:bg-white/5"
          >
            {saved ? "Saved" : "Save profile"}
          </button>
        </form>

        {links.length > 0 && (
          <Panel className="mt-6">
            <p className="micro-cap">Your links</p>
            <ul className="mt-4 space-y-2">
              {links.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="link-underline button-cap inline-block py-2"
                  >
                    {link.label} ↗
                  </Link>
                </li>
              ))}
            </ul>
          </Panel>
        )}
      </div>
    </>
  );
}
