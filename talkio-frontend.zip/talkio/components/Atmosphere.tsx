export function Atmosphere() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
      <div
        className="absolute -top-16 -right-8 h-80 w-80 rounded-full opacity-70 blur-3xl"
        style={{
          background:
            "radial-gradient(circle, var(--gradient-mint) 0%, transparent 68%)",
        }}
      />
      <div
        className="absolute top-[28%] -left-20 h-72 w-72 rounded-full opacity-60 blur-3xl"
        style={{
          background:
            "radial-gradient(circle, var(--gradient-lavender) 0%, transparent 68%)",
        }}
      />
      <div
        className="absolute bottom-32 right-4 h-64 w-64 rounded-full opacity-65 blur-3xl"
        style={{
          background:
            "radial-gradient(circle, var(--gradient-peach) 0%, transparent 68%)",
        }}
      />
      <div
        className="absolute -bottom-8 left-[18%] h-56 w-56 rounded-full opacity-55 blur-3xl"
        style={{
          background:
            "radial-gradient(circle, var(--gradient-sky) 0%, transparent 68%)",
        }}
      />
      <div
        className="absolute top-[55%] right-[20%] h-40 w-40 rounded-full opacity-45 blur-3xl"
        style={{
          background:
            "radial-gradient(circle, var(--gradient-rose) 0%, transparent 68%)",
        }}
      />
    </div>
  );
}
