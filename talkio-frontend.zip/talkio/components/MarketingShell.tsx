import type { ReactNode } from "react";
import { SiteTabs } from "./SiteTabs";

type MarketingShellProps = {
  children: ReactNode;
  wide?: boolean;
};

export function MarketingShell({ children, wide = false }: MarketingShellProps) {
  return (
    <main className="flex flex-1 flex-col">
      <div
        className={`mx-auto w-full px-5 py-8 sm:px-8 lg:px-10 ${
          wide ? "max-w-6xl" : "max-w-[440px] py-10"
        }`}
      >
        <SiteTabs wide={wide} />
        {children}
      </div>
    </main>
  );
}
