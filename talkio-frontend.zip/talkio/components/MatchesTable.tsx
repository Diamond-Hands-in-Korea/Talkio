"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Panel } from "@/components/Panel";
import { loadUserProfile } from "@/lib/profile";
import type { ProfileMatch } from "@/lib/seed";
import { me } from "@/lib/seed";

type MatchesTableProps = {
  matches: ProfileMatch[];
};

export function MatchesTable({ matches }: MatchesTableProps) {
  const [yourGoal, setYourGoal] = useState(me.goals);

  useEffect(() => {
    setYourGoal(loadUserProfile().conferenceGoal || me.goals);
  }, []);

  return (
    <div className="space-y-8">
      <Panel>
        <p className="micro-cap">Your conference goal</p>
        <p className="body-lg mt-3">{yourGoal}</p>
        <p className="micro-cap mt-6 text-on-primary-mute">
          Matches rank people you met against this goal and their profile — backend sync coming soon.
        </p>
      </Panel>

      <div className="data-table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th scope="col">Match</th>
              <th scope="col">Contact</th>
              <th scope="col">Their goals</th>
              <th scope="col">Why you match</th>
              <th scope="col">Overlap</th>
            </tr>
          </thead>
          <tbody>
            {matches.map((match) => (
              <tr key={match.id}>
                <td className="button-cap tabular-nums whitespace-nowrap">
                  {match.matchPercent}%
                </td>
                <td>
                  <p className="button-cap text-on-primary">{match.name}</p>
                  <p className="body-lg mt-1 text-[14px]">{match.headline}</p>
                  <p className="micro-cap mt-2">{match.location}</p>
                  {match.recordingId && (
                    <Link href={`/recordings/${match.recordingId}`} className="table-link mt-3 inline-block">
                      View recording →
                    </Link>
                  )}
                </td>
                <td className="body-lg max-w-[24ch]">{match.theirGoals}</td>
                <td className="body-lg max-w-[32ch]">{match.reason}</td>
                <td>
                  <ul className="data-table-tags">
                    {match.overlapTags.map((tag) => (
                      <li key={tag}>{tag}</li>
                    ))}
                  </ul>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
