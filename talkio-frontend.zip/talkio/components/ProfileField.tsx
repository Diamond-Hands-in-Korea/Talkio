type ProfileFieldProps = {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: "url" | "text";
};

export function ProfileField({
  id,
  label,
  value,
  onChange,
  placeholder,
  type = "url",
}: ProfileFieldProps) {
  return (
    <label htmlFor={id} className="block">
      <span className="micro-cap">{label}</span>
      <input
        id={id}
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="input-dark mt-3"
      />
    </label>
  );
}
