import type { ReactNode } from "react";

type PhotoBandProps = {
  image: string;
  children: ReactNode;
  short?: boolean;
  id?: string;
};

export function PhotoBand({ image, children, short = false, id }: PhotoBandProps) {
  return (
    <section
      id={id}
      className={`photo-band animate-fade-in ${short ? "photo-band-short" : ""}`}
    >
      <div
        className="photo-band-bg"
        style={{ backgroundImage: `url(${image})` }}
        aria-hidden
      />
      <div className="photo-band-content">{children}</div>
    </section>
  );
}
