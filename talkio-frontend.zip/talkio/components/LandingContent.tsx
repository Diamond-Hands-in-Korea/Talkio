import { GhostButton } from "@/components/GhostButton";
import { PhotoBand } from "@/components/PhotoBand";
import { SiteNav } from "@/components/SiteNav";
import { startup } from "@/lib/seed";

const HERO_IMAGE =
  "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=2400&q=80";
const PITCH_IMAGE =
  "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&w=2400&q=80";

export function LandingContent() {
  return (
    <>
      <SiteNav />

      <PhotoBand image={HERO_IMAGE}>
        <p className="micro-cap">Conference networking</p>
        <h1 className="display-xxl mt-4 max-w-[14ch]">{startup.tagline}</h1>
        <p className="body-lg mt-8 max-w-[48ch]">{startup.description}</p>
        <div className="mt-10">
          <GhostButton href="/demo">Try the demo</GhostButton>
        </div>
      </PhotoBand>

      <PhotoBand image={PITCH_IMAGE} short id="mission">
        <p className="micro-cap">The mission</p>
        <h2 className="display-lg mt-4 max-w-[18ch]">Stay present in the room</h2>
        <p className="body-lg mt-8 max-w-[52ch]">{startup.pitch}</p>
        <div className="mt-10">
          <GhostButton href="/demo">Start capturing</GhostButton>
        </div>
      </PhotoBand>

      <section className="content-band" aria-label="How it works">
        <div className="content-band-inner">
          <p className="micro-cap">How it works</p>
          <div className="steps-row mt-10">
            {startup.steps.map((step, index) => (
              <article key={step.title} className="step-item">
                <p className="step-num">{String(index + 1).padStart(2, "0")}</p>
                <h3>{step.title}</h3>
                <p>{step.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <footer className="site-footer">
        <p>Seed-data demo — scan, capture, and follow up in one flow.</p>
      </footer>
    </>
  );
}
