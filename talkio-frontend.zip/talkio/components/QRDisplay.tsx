"use client";

import { QRCodeSVG } from "qrcode.react";
import { Panel } from "./Panel";

type QRDisplayProps = {
  value: string;
};

export function QRDisplay({ value }: QRDisplayProps) {
  return (
    <Panel className="flex animate-fade-in flex-col items-center">
      <QRCodeSVG
        value={value}
        size={168}
        level="M"
        bgColor="#0A0A0A"
        fgColor="#FFFFFF"
        marginSize={0}
      />
      <p className="micro-cap mt-6">Scan to connect at the event</p>
    </Panel>
  );
}
