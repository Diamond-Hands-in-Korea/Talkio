"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { GhostButton } from "@/components/GhostButton";
import { ProfileCard } from "@/components/ProfileCard";
import { QRDisplay } from "@/components/QRDisplay";
import { loadUserProfile } from "@/lib/profile";
import { me, qrValue } from "@/lib/seed";

export function DemoProfileSection() {
  const [conferenceGoal, setConferenceGoal] = useState(me.goals);

  useEffect(() => {
    setConferenceGoal(loadUserProfile().conferenceGoal || me.goals);
  }, []);

  return (
    <div className="space-y-6">
      <ProfileCard profile={{ ...me, goals: conferenceGoal }} />
      <QRDisplay value={qrValue} />
      <GhostButton href="/encounter">I just met someone</GhostButton>
      <p className="body-lg">
        <Link href="/profile" className="link-underline">
          Edit your profile
        </Link>{" "}
        to update links and your conference goal.
      </p>
    </div>
  );
}
