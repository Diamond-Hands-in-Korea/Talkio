type AccentLabelProps = {
  children: React.ReactNode;
  tone?: "mint" | "lavender" | "peach" | "neutral";
};

const toneStyles = {
  mint: "bg-surface-mint text-accent-teal",
  lavender: "bg-surface-lavender text-accent-lavender",
  peach: "bg-surface-peach text-primary",
  neutral: "bg-surface-strong text-muted",
};

export function AccentLabel({ children, tone = "neutral" }: AccentLabelProps) {
  return (
    <span
      className={`inline-block rounded-full px-3 py-1 text-caption-uppercase ${toneStyles[tone]}`}
    >
      {children}
    </span>
  );
}
