import Link from "next/link";
import type { ReactNode } from "react";

type OutlineButtonProps = {
  href?: string;
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
};

export function OutlineButton({
  href,
  children,
  className = "",
  onClick,
  type = "button",
  disabled,
}: OutlineButtonProps) {
  const classes = `inline-flex h-10 flex-1 items-center justify-center rounded-full border border-hairline-strong bg-transparent px-5 text-[15px] font-medium text-ink transition-colors hover:bg-canvas-soft disabled:cursor-default ${className}`;

  if (href) {
    return (
      <Link href={href} className={classes}>
        {children}
      </Link>
    );
  }

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={classes}
    >
      {children}
    </button>
  );
}
