import Link from "next/link";
import type { Recording } from "@/lib/seed";

const statusLabel: Record<Recording["status"], string> = {
  recording: "Recording",
  processing: "Processing",
  complete: "Complete",
};

type RecordingsTableProps = {
  items: Recording[];
};

export function RecordingsTable({ items }: RecordingsTableProps) {
  return (
    <div className="data-table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th scope="col">Contact</th>
            <th scope="col">Event</th>
            <th scope="col">Date</th>
            <th scope="col">Duration</th>
            <th scope="col">Status</th>
            <th scope="col">Summary</th>
            <th scope="col">Highlights</th>
          </tr>
        </thead>
        <tbody>
          {items.map((recording) => (
            <tr key={recording.id}>
              <td>
                <Link href={`/recordings/${recording.id}`} className="table-link">
                  <span className="button-cap block text-on-primary">{recording.contactName}</span>
                  <span className="body-lg mt-1 block text-[14px]">{recording.contactHeadline}</span>
                </Link>
              </td>
              <td className="body-lg">{recording.event}</td>
              <td className="body-lg">{recording.date}</td>
              <td className="button-cap tabular-nums">{recording.duration}</td>
              <td>
                <span className={`status-pill status-pill-${recording.status}`}>
                  {statusLabel[recording.status]}
                </span>
              </td>
              <td className="body-lg max-w-[28ch] truncate">{recording.summary}</td>
              <td className="button-cap tabular-nums">
                {recording.highlights.length > 0 ? recording.highlights.length : "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
