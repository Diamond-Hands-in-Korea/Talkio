"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { TalkioLogo } from "./TalkioLogo";

const tabs = [
  { href: "/", label: "Talkio" },
  { href: "/profile", label: "Profile" },
];

type SiteTabsProps = {
  wide?: boolean;
};

export function SiteTabs({ wide = false }: SiteTabsProps) {
  const pathname = usePathname();

  return (
    <nav
      className={`mb-8 flex gap-1 rounded-full border border-hairline bg-surface-card/90 p-1 shadow-[0_2px_12px_rgba(28,25,23,0.04)] backdrop-blur-sm ${
        wide ? "max-w-md" : ""
      }`}
      aria-label="Site sections"
    >
      {tabs.map((tab) => {
        const active = pathname === tab.href;
        const isHome = tab.href === "/";

        return (
          <Link
            key={tab.href}
            href={tab.href}
            className={`flex flex-1 items-center justify-center gap-2 rounded-full px-4 py-2.5 text-center text-[15px] font-medium transition-colors ${
              active
                ? "bg-surface-mint text-accent-teal"
                : "text-body hover:text-ink"
            }`}
            aria-current={active ? "page" : undefined}
          >
            {isHome && <TalkioLogo size={28} />}
            {tab.label}
          </Link>
        );
      })}
    </nav>
  );
}
