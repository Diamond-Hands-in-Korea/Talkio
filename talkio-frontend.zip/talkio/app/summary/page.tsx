import { ConversationDetailTable } from "@/components/ConversationDetailTable";
import { GhostButton } from "@/components/GhostButton";
import { PageShell } from "@/components/PageShell";
import { SiteNav } from "@/components/SiteNav";
import { contact, highlights, summary, transcript } from "@/lib/seed";

export default function SummaryPage() {
  return (
    <main className="flex flex-1 flex-col bg-canvas-night">
      <SiteNav />
      <PageShell wide>
        <p className="micro-cap">Conversation summary</p>
        <h1 className="display-lg mt-4">What you talked about</h1>

        <div className="mt-10">
          <ConversationDetailTable
            recordingLabel="04:32 · Complete"
            recordingValue={
              <span className="h-2.5 w-2.5 rounded-full bg-on-primary-mute" />
            }
            contactName={contact.name}
            contactHeadline={contact.headline}
            transcript={<span className="whitespace-pre-wrap">{transcript}</span>}
            summary={summary}
            highlights={highlights}
          />
        </div>

        <div className="mt-10 flex flex-wrap gap-4">
          <GhostButton href="/recordings/jiwon-kbw">Save to recordings</GhostButton>
          <GhostButton href="/matches">View profile matches</GhostButton>
        </div>
      </PageShell>
    </main>
  );
}
