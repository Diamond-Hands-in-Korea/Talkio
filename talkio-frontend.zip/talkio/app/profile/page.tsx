import { ProfileEditor } from "@/components/ProfileEditor";

export default function ProfilePage() {
  return (
    <main className="flex flex-1 flex-col bg-canvas-night">
      <ProfileEditor />
    </main>
  );
}
