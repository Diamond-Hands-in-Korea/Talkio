import Link from "next/link";
import { notFound } from "next/navigation";
import { ConversationDetailTable } from "@/components/ConversationDetailTable";
import { GhostButton } from "@/components/GhostButton";
import { PageShell } from "@/components/PageShell";
import { SiteNav } from "@/components/SiteNav";
import { getRecordingById } from "@/lib/seed";

type RecordingDetailPageProps = {
  params: Promise<{ id: string }>;
};

export default async function RecordingDetailPage({ params }: RecordingDetailPageProps) {
  const { id } = await params;
  const recording = getRecordingById(id);

  if (!recording) {
    notFound();
  }

  const isComplete = recording.status === "complete";

  return (
    <main className="flex flex-1 flex-col bg-canvas-night">
      <SiteNav />
      <PageShell wide>
        <Link href="/recordings" className="link-underline micro-cap inline-block">
          ← All recordings
        </Link>

        <p className="micro-cap mt-10">{recording.event}</p>
        <h1 className="display-lg mt-4">{recording.contactName}</h1>
        <p className="body-lg mt-4">
          {recording.date} · {recording.duration} · {recording.status}
        </p>

        <div className="mt-10">
          <ConversationDetailTable
            recordingLabel={recording.duration}
            recordingValue={
              <span
                className={`h-2.5 w-2.5 rounded-full ${
                  recording.status === "recording"
                    ? "animate-pulse-recording bg-on-primary"
                    : "bg-on-primary-mute"
                }`}
              />
            }
            contactName={recording.contactName}
            contactHeadline={recording.contactHeadline}
            transcript={<span className="whitespace-pre-wrap">{recording.transcript}</span>}
            summary={
              recording.status === "complete" || recording.status === "processing"
                ? recording.summary
                : undefined
            }
            highlights={recording.highlights}
            summaryPending={recording.status === "recording"}
            highlightsPending={recording.status !== "complete"}
          />
        </div>

        {isComplete && (
          <div className="mt-10 flex flex-wrap gap-4">
            <GhostButton href="/matches">View profile matches</GhostButton>
            <GhostButton href="/recommendations">Draft follow-up</GhostButton>
          </div>
        )}
      </PageShell>
    </main>
  );
}
