import { GhostButton } from "@/components/GhostButton";
import { PageShell } from "@/components/PageShell";
import { RecordingsTable } from "@/components/RecordingsTable";
import { SiteNav } from "@/components/SiteNav";
import { recordings } from "@/lib/seed";

export default function RecordingsPage() {
  return (
    <main className="flex flex-1 flex-col bg-canvas-night">
      <SiteNav />
      <PageShell wide>
        <p className="micro-cap">Conversation log</p>
        <h1 className="display-lg mt-4">Recordings & summaries</h1>
        <p className="body-lg mt-6 max-w-[60ch]">
          Every captured conversation — recording status, AI summary, and highlight count in
          one place. Backend sync will populate this automatically.
        </p>

        <div className="mt-10">
          <RecordingsTable items={recordings} />
        </div>

        <div className="mt-10">
          <GhostButton href="/demo">Capture a new conversation</GhostButton>
        </div>
      </PageShell>
    </main>
  );
}
