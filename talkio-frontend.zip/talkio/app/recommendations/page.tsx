"use client";

import { useState } from "react";
import { PageShell } from "@/components/PageShell";
import { Panel } from "@/components/Panel";
import { SiteNav } from "@/components/SiteNav";
import { contact, recommendation } from "@/lib/seed";

export default function RecommendationsPage() {
  const [sent, setSent] = useState(false);

  return (
    <main className="flex flex-1 flex-col bg-canvas-night">
      <SiteNav />
      <PageShell>
        <p className="micro-cap">Two days later</p>
        <h1 className="display-lg mt-4">Worth reaching out to now</h1>

        <div className="mt-10 space-y-6">
          <Panel className="animate-fade-in">
            <div className="flex items-start justify-between gap-4">
              <p className="button-cap text-on-primary">{recommendation.name}</p>
              <span className="micro-cap shrink-0 text-on-primary">
                {recommendation.matchPercent}% match
              </span>
            </div>

            <p className="body-lg mt-6">{recommendation.reason}</p>

            <div className="mt-6 border border-hairline-dark px-4 py-4">
              <p className="body-lg italic">{recommendation.draftedMessage}</p>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => setSent(true)}
                disabled={sent}
                className="button-cap inline-flex items-center justify-center rounded-[32px] border border-on-primary px-6 py-[18px] text-on-primary transition-colors hover:bg-white/5 disabled:opacity-70"
              >
                {sent ? "Sent" : "Send"}
              </button>
              <button
                type="button"
                className="button-cap inline-flex items-center justify-center rounded-[32px] border border-hairline-dark px-6 py-[18px] text-on-primary-mute transition-colors hover:border-on-primary-mute"
              >
                Edit
              </button>
            </div>
          </Panel>

          <Panel className="animate-fade-in">
            <p className="micro-cap">Network bridge</p>
            <p className="button-cap mt-4 text-on-primary">
              Intros through {contact.name.split(" ")[0]}&apos;s network
            </p>
            <p className="body-lg mt-4">
              Relay works with three stablecoin issuers and two agent-framework teams
              in Seoul — ask Jiwon for warm intros when your pilot is ready.
            </p>
          </Panel>
        </div>
      </PageShell>
    </main>
  );
}
