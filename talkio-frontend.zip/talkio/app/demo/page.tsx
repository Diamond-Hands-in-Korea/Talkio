import Link from "next/link";
import { DemoProfileSection } from "@/components/DemoProfileSection";
import { PageShell } from "@/components/PageShell";
import { SiteNav } from "@/components/SiteNav";

export default function DemoPage() {
  return (
    <main className="flex flex-1 flex-col bg-canvas-night">
      <SiteNav />
      <PageShell>
        <Link href="/" className="link-underline micro-cap inline-block">
          ← Back to Talkio
        </Link>

        <p className="micro-cap mt-10">Live demo</p>
        <h1 className="display-lg mt-4">You at the event</h1>
        <p className="body-lg mt-6 max-w-[48ch]">
          Scan a contact, capture the conversation, and see what follow-up
          Talkio suggests.
        </p>

        <div className="mt-10">
          <DemoProfileSection />
        </div>
      </PageShell>
    </main>
  );
}
