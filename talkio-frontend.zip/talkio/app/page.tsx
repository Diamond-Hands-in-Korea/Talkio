import { LandingContent } from "@/components/LandingContent";

export default function LandingPage() {
  return (
    <main className="flex flex-1 flex-col">
      <LandingContent />
    </main>
  );
}
