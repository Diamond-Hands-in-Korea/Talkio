import { GhostButton } from "@/components/GhostButton";
import { MatchesTable } from "@/components/MatchesTable";
import { PageShell } from "@/components/PageShell";
import { SiteNav } from "@/components/SiteNav";
import { profileMatches } from "@/lib/seed";

export default function MatchesPage() {
  const sortedMatches = [...profileMatches].sort(
    (a, b) => b.matchPercent - a.matchPercent,
  );

  return (
    <main className="flex flex-1 flex-col bg-canvas-night">
      <SiteNav />
      <PageShell wide>
        <p className="micro-cap">Profile intelligence</p>
        <h1 className="display-lg mt-4">Your best matches</h1>
        <p className="body-lg mt-6 max-w-[60ch]">
          Ranked by overlap between your conference goal and each person&apos;s profile.
          Connected to your profile tab — live backend matching coming soon.
        </p>

        <div className="mt-10">
          <MatchesTable matches={sortedMatches} />
        </div>

        <div className="mt-10">
          <GhostButton href="/profile">Update your profile</GhostButton>
        </div>
      </PageShell>
    </main>
  );
}
