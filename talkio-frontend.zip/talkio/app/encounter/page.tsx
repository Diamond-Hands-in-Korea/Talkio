"use client";

import { useEffect, useMemo, useState } from "react";
import { ConversationDetailTable } from "@/components/ConversationDetailTable";
import { GhostButton } from "@/components/GhostButton";
import { PageShell } from "@/components/PageShell";
import { SiteNav } from "@/components/SiteNav";
import { contact, highlights, summary, transcript } from "@/lib/seed";

function formatTime(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export default function EncounterPage() {
  const tokens = useMemo(() => {
    const result: string[] = [];
    const lines = transcript.split("\n");
    lines.forEach((line, index) => {
      for (const word of line.split(/\s+/).filter(Boolean)) {
        result.push(word);
      }
      if (index < lines.length - 1) {
        result.push("\n");
      }
    });
    return result;
  }, []);
  const [visibleWordCount, setVisibleWordCount] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const transcriptComplete = visibleWordCount >= tokens.length;
  const visibleTranscript = tokens
    .slice(0, visibleWordCount)
    .reduce((acc, token) => {
      if (token === "\n") return `${acc}\n`;
      const spacer = acc.endsWith("\n") || acc.length === 0 ? "" : " ";
      return acc + spacer + token;
    }, "");

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (visibleWordCount >= tokens.length) return;

    const stream = setInterval(() => {
      setVisibleWordCount((prev) => Math.min(prev + 1, tokens.length));
    }, 110);

    return () => clearInterval(stream);
  }, [visibleWordCount, tokens.length]);

  return (
    <main className="flex flex-1 flex-col bg-canvas-night">
      <SiteNav />
      <PageShell wide>
        <p className="micro-cap">Live capture</p>
        <h1 className="display-lg mt-4">Recording in progress</h1>

        <div className="mt-10">
          <ConversationDetailTable
            recordingLabel={`Live · ${formatTime(elapsedSeconds)}`}
            recordingValue={
              <span className="h-2.5 w-2.5 animate-pulse-recording rounded-full bg-on-primary" />
            }
            contactName={contact.name}
            contactHeadline={contact.headline}
            transcript={
              <span className="whitespace-pre-wrap">
                {visibleTranscript}
                {!transcriptComplete && (
                  <span className="ml-0.5 inline-block h-4 w-0.5 animate-pulse bg-on-primary align-middle" />
                )}
              </span>
            }
            summary={transcriptComplete ? summary : undefined}
            highlights={transcriptComplete ? highlights : undefined}
            summaryPending={!transcriptComplete}
            highlightsPending={!transcriptComplete}
          />
        </div>

        <div className="mt-10">
          <GhostButton href="/summary">End conversation</GhostButton>
        </div>
      </PageShell>
    </main>
  );
}
